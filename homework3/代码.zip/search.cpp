#include<iostream>
using namespace std;
const int MAXN = 1e7 + 10;
int T[MAXN];

//˳�����
int Sequential_Search(int n, int x) 
{
	for (int i = 1; i <= n; i++) {
		if (T[i] == x) {
			return i;
		}
	}
	return 0;
}



//���ֲ���
int Binary_Search(int n, int x) 
{
	int mid;
	int low = 1, high = n;
	while (low <= high) {
		mid = low + (high - low) / 2;
		if (T[mid] == x) {
			return mid;
		}else {
			if (x < T[mid]) high = mid - 1;
			else low = mid + 1;
		}
	}
	return 0;
}
int main()
{
	int N[20] = {1,2,3,4,5,6,7,8,9,10,11,22,33,44,55,66,77};
	int n = N[0];
	
	for (int i = 1; i <= n; i++) {
		T[i] = i;
	}
	for(int i = 1; i <= n + 1; i++)
	{
		cout << "Sequential search is: " << Sequential_Search(n, i) << endl;
		cout << "Binary search: " << Binary_Search(n, i) << endl;
		cout <<endl;
	}
	
	return 0;
}

